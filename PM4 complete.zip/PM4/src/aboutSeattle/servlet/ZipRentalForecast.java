package aboutSeattle.servlet;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/rentalforecast")
public class ZipRentalForecast extends HttpServlet {
	
	protected RentalForecastDao rentalForecastDao;
	
	@Override
	public void init() throws ServletException {
		rentalForecastDao = RentalForecastDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
        List<RentalForecast> rentalForecast = new ArrayList<>();
        
		// Retrieve RentalForecasts depending on valid zipcode or forecastId.
        String zipcode = req.getParameter("zipcode");
        
        try {
	        if (zipcode != null && !zipcode.trim().isEmpty()) {
	        	// If the postid param is provided then ignore the username param.
	        	int zip = Integer.parseInt(zipcode);
	        	rentalForecast = rentalForecastDao.getRentalForecastByZip(zip);
	        	messages.put("title", "RentalForecast for ZipCode " + zipcode);
	        } else {
	        	messages.put("title", "Invalid ZipCode.");
	        }
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        
        req.setAttribute("rentalForecast", rentalForecast);
        req.getRequestDispatcher("/ZipRentalForecast.jsp").forward(req, resp);
	}
}
