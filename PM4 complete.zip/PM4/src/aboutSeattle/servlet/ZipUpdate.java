package aboutSeattle.servlet;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/zipupdate")
public class ZipUpdate extends HttpServlet {
	
	protected ZipCodeDao zipCodeDao;
	
	@Override
	public void init() throws ServletException {
		zipCodeDao = ZipCodeDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        // Retrieve user and validate.
        String zipCode = req.getParameter("zipcode");
        if (zipCode == null || zipCode.trim().isEmpty()) {
            messages.put("success", "Please enter a valid ZipCode.");
        } else {
        	try {
        		int zip = Integer.parseInt(zipCode);
        		ZipCodes newZipCode = zipCodeDao.getZipByZipCode(zip);
        		if(newZipCode == null) {
        			messages.put("success", "ZipCode does not exist.");
        		}
        		req.setAttribute("zipCode", newZipCode);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ZipUpdate.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        // Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        // Retrieve user and validate.
        String zipCode = req.getParameter("zipcode");
        if (zipCode == null || zipCode.trim().isEmpty()) {
            messages.put("success", "Please enter a valid UserName.");
        } else {
        	try {
        		int zip = Integer.parseInt(zipCode);
        		ZipCodes zipC = zipCodeDao.getZipByZipCode(zip);
        		if(zipC == null) {
        			messages.put("success", "ZipCode does not exist. No update to perform.");
        		} else {
        			String newCity = req.getParameter("city");
        			if (newCity == null || newCity.trim().isEmpty()) {
        	            messages.put("success", "Please enter a valid city.");
        	        } else {
        	        	zipC = zipCodeDao.updateCity(zipC, newCity);
        	        	messages.put("success", "Successfully updated " + zipC);
        	        }
        		}
        		req.setAttribute("zipCode", zipC);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ZipUpdate.jsp").forward(req, resp);
    }
}
