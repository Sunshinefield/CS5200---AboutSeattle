package aboutSeattle.servlet;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/historicalrental")
public class ZipHistoricalRental extends HttpServlet {
	
	protected HistoricalRentalDao historicalRentalDao;
	
	@Override
	public void init() throws ServletException {
		historicalRentalDao = HistoricalRentalDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
		// Retrieve and validate ZipCodes.
        String zipCode = req.getParameter("zipcode");
        if (zipCode == null || zipCode.trim().isEmpty()) {
            messages.put("title", "Invalid zipCode.");
        } else {
        	messages.put("title", "HistoricalRental for " + zipCode);
        }
        
        // Retrieve Historical Rentals, and store in the request.
        List<HistoricalRental> historicalRental = new ArrayList<>();
        try {
        	int zip = Integer.parseInt(zipCode);
        	historicalRental = historicalRentalDao.getHistoricalRenatlByZip(zip);
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        req.setAttribute("historicalRental", historicalRental);
        req.getRequestDispatcher("/ZipHistoricalRental.jsp").forward(req, resp);
	}
}
