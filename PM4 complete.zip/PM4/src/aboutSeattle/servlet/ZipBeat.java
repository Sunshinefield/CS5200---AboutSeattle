package aboutSeattle.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;


@WebServlet("/beat")
public class ZipBeat extends HttpServlet {
	
	protected BeatDao beatDao;
	
	@Override
	public void init() throws ServletException {
		beatDao = BeatDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        
		// Retrieve the zipcode.
        String zipcode = req.getParameter("zipcode");
        
        if (zipcode == null || zipcode.trim().isEmpty()) {
            messages.put("title", "Invalid zipCode.");
        } else {
        	messages.put("title", "Beat for " + zipcode);
        }
        
        //Retrieves the Beats associated with the ZipCode.
        List<Beat> beats = new ArrayList<Beat>();
        try {
        	int newZipCode = Integer.parseInt(zipcode);
        	beats = beatDao.getBeatFromZipCode(newZipCode);
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        req.setAttribute("beats", beats);
        req.getRequestDispatcher("/beats.jsp").forward(req, resp);
	}
}
