//Zhihua Wu/Ugochi Madubata

package aboutSeattle.tools;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.sql.Date;
import java.util.List;


/**
 * main() runner, used for the app demo.
 * 
 * Instructions:
 * 1. Create a new MySQL schema and then run the CREATE TABLE statements from lecture:
 * http://goo.gl/86a11H.
 * 2. Update ConnectionManager with the correct user, password, and schema.
 */
public class Inserter {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws SQLException, ParseException {
		// DAO instances.
		
		CrimesDao crimesDao = CrimesDao.getInstance();
		HistoricalRentalDao historicalRentalDao = HistoricalRentalDao.getInstance();
		RentalForecastDao rentalForecastDao = RentalForecastDao.getInstance();
		BeatDao beatDao = BeatDao.getInstance();
		ZipCodeDao zipCodeDao = ZipCodeDao.getInstance();
		
		
		// INSERT objects from our model.
		
		
		
		ZipCodes zip1 = new ZipCodes(98052, "Remond", "King", "WA");
		zip1 = zipCodeDao.create(zip1);
		ZipCodes zip2 = new ZipCodes(98012, "Bothell", "Snohomish", "WA");
		zip2 = zipCodeDao.create(zip2);
		ZipCodes zip3 = new ZipCodes(98103, "Seattle", "King", "WA");
		zip3 = zipCodeDao.create(zip3);
		ZipCodes zip4 = new ZipCodes(98109, "Seattle", "King", "WA");
		zip4 = zipCodeDao.create(zip4);
		ZipCodes zip5 = new ZipCodes(98121, "Seattle", "King", "WA");
		zip5 = zipCodeDao.create(zip5);

		
		Beat beat1 = new Beat("N4", 47.698470493248998, -122.351867710243, zip1);
		beat1 = beatDao.create(beat1);
		Beat beat2 = new Beat("J3", 47.656378177487703, -122.336468775341, zip3);
		beat2 = beatDao.create(beat2);
		Beat beat3 = new Beat("N2", 47.698470493248998, -122.351867710243, zip3);
		beat3 = beatDao.create(beat3);
		
		HistoricalRental historicalRental1 = new HistoricalRental(zip1, "Redmond", "WA", "Seattle-Tacoma-Bellevue", "King", 
				1.4180000000, 1.4180000000, 1.4010000000, 1.4010000000, 1.6290000000, 1.6290000000);
		historicalRental1 = historicalRentalDao.create(historicalRental1);
		HistoricalRental historicalRental2 = new HistoricalRental(zip2, "Bothell", "WA", "Seattle-Tacoma-Bellevue", "Snohomish", 
				1.1340000000, 1.0980000000, 1.1430000000, 1.2050000000, 1.2480000000, 1.2680000000);
		historicalRental2 = historicalRentalDao.create(historicalRental2);
		HistoricalRental historicalRental3 = new HistoricalRental(zip3, "Seattle", "WA", "Seattle-Tacoma-Bellevue", "King", 
				1.7760000000, 1.8420000000, 1.9010000000, 2.0860000000, 2.1400000000, 2.2400000000);
		historicalRental3 = historicalRentalDao.create(historicalRental3);
		HistoricalRental historicalRental4 = new HistoricalRental(zip4, "Seattle", "WA", "Seattle-Tacoma-Bellevue", "King", 
				2.2700000000, 2.1780000000, 2.4110000000, 2.5000000000, 2.6800000000, 2.6700000000);
		historicalRental4 = historicalRentalDao.create(historicalRental4);
		HistoricalRental historicalRental5 = new HistoricalRental(zip5, "Seattle", "WA", "Seattle-Tacoma-Bellevue", "King", 
				2.5490000000, 2.7170000000, 2.8730000000, 2.9530000000, 3.1750000000, 3.1690000000);
		historicalRental5 = historicalRentalDao.create(historicalRental5);

		//Create a Date value
		Date date = Date.valueOf("2018-9-30");
		Date date2 = Date.valueOf("2008-8-9");
		Date date3 = Date.valueOf("2008-1-2");
		Date date4 = Date.valueOf("2008-8-4");
		Date date5 = Date.valueOf("2007-12-29");
		
		
		RentalForecast rentalForecast1 = new RentalForecast(zip1,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Redmond",75,2586,-0.052400147000,19679);
		rentalForecast1 = rentalForecastDao.create(rentalForecast1);

		RentalForecast rentalForecast2 = new RentalForecast(zip2,date,"WA","Seattle-Tacoma-Bellevue",
				"Snohomish","Bothell",152,2294,-0.041771094000,20473);
		rentalForecast2 = rentalForecastDao.create(rentalForecast2);

		RentalForecast rentalForecast3 = new RentalForecast(zip3,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Seattle",189,2569,-0.074234234000,17641);
		rentalForecast3 = rentalForecastDao.create(rentalForecast3);
		RentalForecast rentalForecast4 = new RentalForecast(zip4,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Seattle",804,2338,-0.065920895000,7472);
		rentalForecast4 = rentalForecastDao.create(rentalForecast4);
		RentalForecast rentalForecast5 = new RentalForecast(zip5,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Seattle",2539,2212,-0.031099431000,6199);
		rentalForecast5 = rentalForecastDao.create(rentalForecast5);
		
		String rawTimestamp = "1841";
		String rawTimestamp2 = "1550";
		String rawTimestamp3 = "1300";
		
		Crimes crime1 = new Crimes(date2, date4, Crimes.CrimeSubCat.THEFT_BUILDING,  "THEFT-BUILDING", "NORTH", "J", beat2, "PHINNEY RIDGE");
		crime1 = crimesDao.create(crime1);
		Crimes crime2 = new Crimes(date3, date5, Crimes.CrimeSubCat.SEX_OFFENSE_OTHER,  "SEX_OFFENSE_OTHER", "NORTH", "J", beat2, "ROOSEVELT/RAVENNA");
		crime2 = crimesDao.create(crime2);
		Crimes crime3 = new Crimes(date, date, Crimes.CrimeSubCat.FAMILY_OFFENSE_NONVIOLENT,  "CHILD-OTHER", "NORTH", "N", beat3, "BITTERLAKE");
		crime3 = crimesDao.create(crime3);
		// READ.
		
		ZipCodes z1 = zipCodeDao.getZipByZipCode(98103);
		System.out.format("Reading ZipCodes:%n z:%d%n c:%s%n ct:%s%n s:%s%n\n",
				z1.getZip(),
				z1.getCity(),
				z1.getCounty(),
				z1.getState());
		
		List<ZipCodes> zList1 = zipCodeDao.getZipByCity("Seattle");
		for(ZipCodes z : zList1) {
			System.out.format("Looping ZipCodes:%n z:%d%n c:%s%n ct:%s%n s:%s%n\n",
					z.getZip(),
					z.getCity(),
					z.getCounty(),
					z.getState());
		}
		
		
		Beat b1 = beatDao.getBeatFromBeat("N4");
		System.out.format("Reading Beat:%n b:%s%n lat:%f%n long:%f%n z:%d%n\n", 
				b1.getBeat().toString(),
				b1.getLatitude(),
				b1.getLongitude(),
				b1.getZipCode().getZip());
		
		List<Beat> bList1 = beatDao.getBeatFromZipCode(98103);
		for(Beat b : bList1) {
			System.out.format("Looping Beats:%n b:%s%n lat:%f%n long:%f%n z:%d%n\n", 
					b.getBeat().toString(),
					b.getLatitude(),
					b.getLongitude(),
					b.getZipCode().getZip());
		}
		
		
		HistoricalRental h1 = historicalRentalDao.getHistoricalRentalById(1);
		System.out.format("Reading HistoricalRental:%n z:%d%n c:%s%n s:%s%n m:%s%n ct:%s%n p13:%.4f%n p14:%.4f%n p15:%.4f%n p16:%.4f%n p17:%.4f%n p18:%.4f%n\n",
				h1.getZip().getZip(),
				h1.getCity(),
				h1.getState(),
				h1.getMetro(),
				h1.getCounty(),
				h1.getP2013(),
				h1.getP2014(),
				h1.getP2015(),
				h1.getP2016(),
				h1.getP2017(),
				h1.getP2018());
		

		List<HistoricalRental> hList1 = historicalRentalDao.getHistoricalRenatlByZip(98004);
		for(HistoricalRental h : hList1 ) {
			System.out.format("Looping historicalRental:%n z:%d%n c:%s%n s:%s%n m:%s%n ct:%s%n p13:%.4f%n p14:%.4f%n p15:%.4f%n p16:%.4f%n p17:%.4f%n p18:%.4f%n\n",
					h.getZip().getZip(),
					h.getCity(),
					h.getState(),
					h.getMetro(),
					h.getCounty(),
					h.getP2013(),
					h.getP2014(),
					h.getP2015(),
					h.getP2016(),
					h.getP2017(),
					h.getP2018());
		}

		
		List<RentalForecast> rList = rentalForecastDao.getRentalForecastByZip(98103);
		for(RentalForecast r : rList) {
			System.out.format("Reading RentalForecast:%n z:%d%n d:%s%n s:%s%n m:%s%n ct:%s%n c:%s%n sr:%d%n zrt:%d%n yoy:%.4f%n zricnt:%d%n\n",
					r.getZip().getZip(),
					r.getDate(),
					r.getState(),
					r.getMetro(),
					r.getCounty(),
					r.getCity(),
					r.getSizeRank(),
					r.getZri(),
					r.getYoy(),
					r.getZriRecordCnt());
		}
		
		
		List<RentalForecast> rList1 = rentalForecastDao.getRentalForecastByCity("Seattle");
		for(RentalForecast r : rList1) {
			System.out.format("Looping RentalForecast:%n z:%d%n d:%s%n s:%s%n m:%s%n ct:%s%n c:%s%n sr:%d%n zrt:%d%n yoy:%.4f%n zricnt:%d%n\n",
					r.getZip().getZip(),
					r.getDate(),
					r.getState(),
					r.getMetro(),
					r.getCounty(),
					r.getCity(),
					r.getSizeRank(),
					r.getZri(),
					r.getYoy(),
					r.getZriRecordCnt());
		}
		
		List<Crimes> cList1 = crimesDao.getCrimeByZipCode(98103);
		for(Crimes c : cList1) {
			System.out.format("Looping Crimes by Neighborhood:%n r:%d%n rd:%s%n rt:%s%n od:%s%n csc:%s%n d:%s%n p:%s%n s:%s%n b:%s%n n:%s%n\n",
					c.getReportId(),
					c.getReportedDate().toString(),
					c.getOccuredDate().toString(),
					c.getCrimeSubCat().getCrime(),
					c.getDescription(),
					c.getPrecinct(),
					c.getSector(),
					c.getBeat().getBeat().toString(),
					c.getNeighborhood());
		}
		
		List<String> cList2 = crimesDao.getCrimeNumbersByZipCode(zip3.getZip(), date2.getYear(), date.getYear());
		for(String c : cList2) {
			System.out.format("Looping Crimes by zipcode:%n %s%n\n", c);
		}
		

		//Update
		Beat beatUpdate = beatDao.updateLatitude(beat1, 47.680853154025499);
		System.out.format("Updating beat: %n b:%s%n lat:%f%n long:%f%n z:%d%n\n", 
				beatUpdate.getBeat(), beatUpdate.getLatitude(), beatUpdate.getLongitude(), beatUpdate.getZipCode().getZip());
		
		HistoricalRental historicalRentalUpdate = historicalRentalDao.updateCity(historicalRental1, "NewCity");
		System.out.format("Updating historicalRental: li:%d c:%s z:%s \n",
				historicalRentalUpdate.getListingId(), historicalRentalUpdate.getCity() ,historicalRentalUpdate.getZip().getZip());
		
		RentalForecast rentalForecastUpdate =  rentalForecastDao.updateCity(rentalForecast1, "NewCity");
		System.out.format("Updating rentalForecast: fi:%d c:%s z:%s  \n",
				rentalForecastUpdate.getForecastId(), rentalForecastUpdate.getCity(), rentalForecastUpdate.getZip().getZip());

		ZipCodes zipCodeUpdate =  zipCodeDao.updateCity(zip1, "NewCity");
		System.out.format("Updating zipcode: fi:%d c:%s z:%s  \n",
				zipCodeUpdate.getZip(), zipCodeUpdate.getCity(), zipCodeUpdate.getState());

		
		//Delete
		Crimes deleteCrime = crimesDao.delete(crime1);
		System.out.format("Deleted 1st crime:" + deleteCrime + "\n");
		
		Beat deleteBeat = beatDao.delete(beat1);
		System.out.format("Deleted 1st beat:" + deleteBeat + "\n");
		
		HistoricalRental deleteHistoricalRental = historicalRentalDao.delete(historicalRental1);
		System.out.println("Deleted 1st historicalRental:"+ deleteHistoricalRental);
		
		RentalForecast deleteRentalForecast = rentalForecastDao.delete(rentalForecast1);
		System.out.println("Deleted 1st rentalForecast:"+ deleteRentalForecast);
		
		ZipCodes deleteZipCode = zipCodeDao.delete(zip1);
		System.out.println("Deleted 1st zipcode:"+ deleteZipCode);
		
		
		
	}
}
