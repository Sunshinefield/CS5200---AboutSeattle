//Zhihua Wu

package aboutSeattle.dal;

import aboutSeattle.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 * Data access object (DAO) class to interact with the underlying Users table in your MySQL
 * instance. This is used to store {@link ZipCodes} into your MySQL instance and retrieve 
 * {@link ZipCodes} from MySQL instance.
 */
public class ZipCodeDao {
	protected ConnectionManager connectionManager;
	
	// Single pattern: instantiation is limited to one object.
	private static ZipCodeDao instance = null;
	protected ZipCodeDao() {
		connectionManager = new ConnectionManager();
	}
	public static ZipCodeDao getInstance() {
		if(instance == null) {
			instance = new ZipCodeDao();
		}
		return instance;
	}

	/**
	 * Save the User instance by storing it in your MySQL instance.
	 * This runs a INSERT statement.
	 */
	
	public ZipCodes create(ZipCodes zip) throws SQLException {
		String insertZip = "INSERT INTO ZipCodes(ZipCode,City,County,State)"
				+ " VALUES(?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertZip);
			
			insertStmt.setInt(1, zip.getZip());
			insertStmt.setString(2, zip.getCity());
			insertStmt.setString(3, zip.getCounty());
			insertStmt.setString(4, zip.getState());
			 
			insertStmt.executeUpdate();
			return zip;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}// end of insert
	

	/**
	 * Update the LastName of the User instance.
	 * This runs a UPDATE statement.
	 */
	public ZipCodes updateCity(ZipCodes zip, String newCity) throws SQLException {
		String updateZip = "UPDATE ZipCodes SET City=? WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateZip);
			updateStmt.setString(1, newCity);
			updateStmt.setInt(2, zip.getZip());
			updateStmt.executeUpdate();
			
			// Update the person param before returning to the caller.
			zip.setCity(newCity);
			return zip;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}

	/**
	 * Delete the ZipCode instance.
	 * This runs a DELETE statement.
	 */
	public ZipCodes delete(ZipCodes zip) throws SQLException {
		String deleteZip = "DELETE FROM ZipCodes WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteZip);
			deleteStmt.setInt(1, zip.getZip());
			deleteStmt.executeUpdate();

			// Return null so the caller can no longer operate on the User instance.
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}


	/**
	 * Get the ZipCode record by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns a single ZipCode instance.
	 */
	public ZipCodes getZipByZipCode(int zip) throws SQLException {
		String selectZip = "SELECT * FROM ZipCodes WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectZip);
			selectStmt.setInt(1, zip);
			// Note that we call executeQuery(). This is used for a SELECT statement
			// because it returns a result set. For more information, see:
			// http://docs.oracle.com/javase/7/docs/api/java/sql/PreparedStatement.html
			// http://docs.oracle.com/javase/7/docs/api/java/sql/ResultSet.html
			results = selectStmt.executeQuery();
			// You can iterate the result set (although the example below only retrieves 
			// the first record). The cursor is initially positioned before the row.
			// Furthermore, you can retrieve fields by name and by type.
			if(results.next()) {
				int resultZip = results.getInt("ZipCode");
				String state = results.getString("State");
				String county = results.getString("County");
				String city = results.getString("City");
				ZipCodes zipcode = new ZipCodes(resultZip, city, county, state);
				return zipcode;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}

	/**
	 * Get the matching Persons records by fetching from your MySQL instance.
	 * This runs a SELECT statement and returns a list of matching Persons.
	 */
	public List<ZipCodes> getZipByCity(String city) throws SQLException {
		List<ZipCodes> zipcodes = new ArrayList<>();
		String selectZipCodes =
			"SELECT City,ZipCode,State,County FROM ZipCodes WHERE City=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectZipCodes);
			selectStmt.setString(1, city);
			results = selectStmt.executeQuery();
			while(results.next()) {
				String resultCity = results.getString("City");
				int zip = results.getInt("ZipCode");
				String state = results.getString("State");
				String county = results.getString("County");
				ZipCodes zipcode = new ZipCodes(zip, resultCity, county, state);
				zipcodes.add(zipcode);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return zipcodes;
	}
}
