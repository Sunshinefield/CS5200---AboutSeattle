// Ugochi Madubata

package aboutSeattle.dal;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import aboutSeattle.model.*;
import aboutSeattle.model.Crimes.CrimeSubCat;

/**
 * Data access object (DAO) class to interact with the underlying Crimes table in your
 * MySQL instance. This is used to store {@link Crimes} into your MySQL instance and 
 * retrieve {@link Crimes} from MySQL instance.
 */
public class CrimesDao {
	protected ConnectionManager connectionManager;

	private static CrimesDao instance = null;
	protected CrimesDao() {
		connectionManager = new ConnectionManager();
	}
	public static CrimesDao getInstance() {
		if(instance == null) {
			instance = new CrimesDao();
		}
		return instance;
	}

	/**
	 * Save the Crimes instance by storing it in your MySQL instance.
	 * This runs a INSERT statement.
	 * @throws ParseException 
	 */
	public Crimes create(Crimes crime) throws SQLException, ParseException {
		String insertCrime =
			"INSERT INTO Crimes(ReportedDate,OccurDate, CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood) " +
			"VALUES(?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertCrime,
				Statement.RETURN_GENERATED_KEYS);
			Date date = (Date) crime.getReportedDate();
			String dateString = date.toString();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate updatedDate = LocalDate.parse(dateString, formatter);
			Date reportedDate = Date.valueOf(updatedDate);
			insertStmt.setDate(1, reportedDate);
			insertStmt.setTimestamp(2, null);
			Date date2 = (Date) crime.getOccuredDate();
			String dateString2 = date2.toString();
			LocalDate updatedDate2 = LocalDate.parse(dateString2, formatter);
			Date reportedDate2 = Date.valueOf(updatedDate2);
			insertStmt.setDate(3, reportedDate2);
			insertStmt.setString(4, crime.getCrimeSubCat().getCrime());
			insertStmt.setString(5,  crime.getDescription());
			insertStmt.setString(6, crime.getPrecinct());
			insertStmt.setString(7, crime.getSector());
			insertStmt.setString(8, crime.getBeat().getBeat());
			insertStmt.setString(9,  crime.getNeighborhood());
			insertStmt.executeUpdate();
			
			// Retrieve the auto-generated key and set it, so it can be used by the caller.
			resultKey = insertStmt.getGeneratedKeys();
			int reportId = -1;
			if(resultKey.next()) {
				reportId = resultKey.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			crime.setReportId(reportId);
			return crime;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}
	
	/**
	 * Get the Crimes record by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns a single Crimes instance.
	 */
	public Crimes getCrimeById(int reportId) throws SQLException {
		String selectCrime =
			"SELECT ReportId,ReportedDate,OccurDate,CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood " +
			"FROM " +
			"WHERE ReportId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrime);
			selectStmt.setInt(1, reportId);
			results = selectStmt.executeQuery();
			BeatDao beatDao = BeatDao.getInstance();
			
			if(results.next()) {
				long resultReportId = results.getLong("ReportId");
				Date reportedDate =  new Date(results.getTimestamp("ReportedDate").getTime());
				Date occuredDate = new Date(results.getTimestamp("OccurDate").getTime());
				String crimeSubCat = results.getString("CrimeSubCat");
				String description = results.getString("Description");
				String precinct = results.getString("Precinct");
				String sector = results.getString("Sector");
				String beat = results.getString("Beat");
				String neighborhood = results.getString("Neighborhood");
				
				Beat newBeat = beatDao.getBeatFromBeat(beat);
				CrimeSubCat newCrimeSubCat = CrimeSubCat.valueOf(crimeSubCat);
				
				Crimes crime = new Crimes(resultReportId, reportedDate, occuredDate,
						 newCrimeSubCat, description, precinct, sector, newBeat, neighborhood);
				return crime;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	
	public List<Crimes> getCrimeByZipCode(int zipcode) throws SQLException {
		List<Crimes> crimes = new ArrayList<Crimes>();
		String selectCrime =
			"SELECT ReportId,ReportedDate,ReportedTime,OccurDate, CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood " +
			"FROM " +
				"(SELECT ReportId,ReportedDate,ReportedTime,OccurDate, CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood,BeatCrimes.ZipCode AS ZipCode " +
				"FROM " + 
					"(SELECT ReportId,ReportedDate,ReportedTime,OccurDate, CrimeSubCat,Description,Precinct,Sector,Crimes.Beat AS Beat,Neighborhood,Beat.ZipCode AS ZipCode " +
					  "FROM Crimes INNER JOIN Beat " +
						"ON Crimes.Beat = Beat.Beat " +
					") AS BeatCrimes INNER JOIN ZipCodes " +
						"ON BeatCrimes.ZipCode = ZipCodes.ZipCode) AS NewTable " +
				"WHERE ZipCode=? "
				+ "ORDER BY OccurDate DESC "
				+ "LIMIT 10;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrime);
			selectStmt.setInt(1, zipcode);
			results = selectStmt.executeQuery();
			BeatDao beatDao = BeatDao.getInstance();
			
			while(results.next()) {
				long resultReportId = results.getLong("ReportId");
				Date reportedDate =  new Date(results.getTimestamp("ReportedDate").getTime());
				Date occuredDate = new Date(results.getTimestamp("OccurDate").getTime());
				String crimeSubCat = results.getString("CrimeSubCat");
				String description = results.getString("Description");
				String precinct = results.getString("Precinct");
				String sector = results.getString("Sector");
				String beat = results.getString("Beat");
				String neighborhood = results.getString("Neighborhood");
				
				Beat newBeat = beatDao.getBeatFromBeat(beat);
				CrimeSubCat newCrimeSubCat = Crimes.CrimeSubCat.fromString(crimeSubCat);
				
				Crimes crime = new Crimes(resultReportId, reportedDate, occuredDate,
						 newCrimeSubCat, description, precinct, sector, newBeat, neighborhood);
				crimes.add(crime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimes;
	}

	/**
	 * Get the all the Crimes for a neighborhood in a certain year.
	 */
	public List<Crimes> getCrimesByNeighborhood(String neighborhood, int year) throws SQLException {
		List<Crimes> crimes = new ArrayList<Crimes>();
		String selectCrimes =
			"SELECT ReportId,ReportedDate,ReportedTime,OccurDate,CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood " +
			"FROM Crimes " +
			"WHERE Neighborhood=? AND OccurDate BETWEEN ? AND ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrimes);
			selectStmt.setString(1, neighborhood);
			Date beginning = new Date(year, 1, 1);
			Date end = new Date(year, 12, 31);
			java.sql.Date beginning2 = new java.sql.Date(beginning.getTime());
			java.sql.Date end2 = new java.sql.Date(end.getTime());
			selectStmt.setDate(2, beginning2);
			selectStmt.setDate(3, end2);
			results = selectStmt.executeQuery();
			BeatDao beatDao = BeatDao.getInstance();
			
			while(results.next()) {
				System.out.println("Got Something");
				long resultReportId = results.getLong("ReportId");
				Date reportedDate =  new Date(results.getTimestamp("ReportedDate").getTime());
				Date occuredDate = new Date(results.getTimestamp("OccurDate").getTime());
				String crimeSubCat = results.getString("CrimeSubCat");
				String description = results.getString("Description");
				String precinct = results.getString("Precinct");
				String sector = results.getString("Sector");
				String beat = results.getString("Beat");
				String newNeighborhood = results.getString("Neighborhood");

				Beat newBeat = beatDao.getBeatFromBeat(beat);
				CrimeSubCat newCrimeSubCat = CrimeSubCat.valueOf(crimeSubCat);
				
				Crimes crime = new Crimes(resultReportId, reportedDate, occuredDate,
						 newCrimeSubCat, description, precinct, sector, newBeat, newNeighborhood);
				crimes.add(crime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimes;
	}
	
	/**
	 * Get the all the Crimes for a beat during a certain year.
	 */
	@SuppressWarnings("deprecation")
	public List<Crimes> getCrimesByBeat(String beat, int year) throws SQLException {
		List<Crimes> crimes = new ArrayList<Crimes>();
		String selectCrimes =
			"SELECT ReportId,ReportedDate,ReportedTime,OccurDate, CrimeSubCat,Description,Precinct,Sector,Beat,Neighborhood " +
			"FROM Crimes " +
			"WHERE Beat=? AND OccurDate BETWEEN ? AND ?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrimes);
			selectStmt.setString(1, beat);
			Date beginning = new Date(year, 1, 1);
			Date end = new Date(year, 12, 31);
			java.sql.Date beginning2 = new java.sql.Date(beginning.getTime());
			java.sql.Date end2 = new java.sql.Date(end.getTime());
			selectStmt.setDate(2, beginning2);
			selectStmt.setDate(3, end2);
			results = selectStmt.executeQuery();
			BeatDao beatDao = BeatDao.getInstance();
			
			while(results.next()) {
				long resultReportId = results.getLong("ReportId");
				Date reportedDate =  new Date(results.getTimestamp("ReportedDate").getTime());
				Date occuredDate = new Date(results.getTimestamp("OccurDate").getTime());
				String crimeSubCat = results.getString("CrimeSubCat");
				String description = results.getString("Description");
				String precinct = results.getString("Precinct");
				String sector = results.getString("Sector");
				String resultsBeat = results.getString("Beat");
				String neighborhood = results.getString("Neighborhood");

				Beat newBeat = beatDao.getBeatFromBeat(resultsBeat);
				CrimeSubCat newCrimeSubCat = CrimeSubCat.valueOf(crimeSubCat);
				
				Crimes crime = new Crimes(resultReportId, reportedDate, occuredDate,
						 newCrimeSubCat, description, precinct, sector, newBeat, neighborhood);
				crimes.add(crime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimes;
	}
	
	/**
	 * Get the amount of crimes in a neighborhood by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns the name of the neighborhood and the number of crimes
	 * that occurred in a time range.
	 */
	@SuppressWarnings("deprecation")
	public List<String> getCrimeNumbersByNeighborhood(String neighborhood, int beginningYear, int endYear) throws SQLException {
		List<String> crimeStats = new ArrayList<String>();
		String selectCrimeStats =
			"SELECT Neighborhood,CrimeSubCat, COUNT(*) AS CNT " +
			"FROM Crimes " +
			"WHERE Neighborhood=? AND OccurDate BETWEEN ? AND ?" +
			"GROUP BY CrimeSubCat;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrimeStats);
			selectStmt.setString(1,	neighborhood);
			Date beginning = new Date(beginningYear, 1, 1);
			Date end = new Date(endYear, 12, 31);
			java.sql.Date beginning2 = new java.sql.Date(beginning.getTime());
			java.sql.Date end2 = new java.sql.Date(end.getTime());
			selectStmt.setDate(2, beginning2);
			selectStmt.setDate(3, end2);
			results = selectStmt.executeQuery();
			
			while(results.next()) {
				String resultNeighborhood = results.getString("Neighborhood");
				String crimeSubCat = results.getString("CrimeSubCat");
				int cnt = results.getInt("CNT");
				
				String returnResult = resultNeighborhood + ": " + crimeSubCat + " - " + cnt;
				crimeStats.add(returnResult);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimeStats;
	}
	
	/**
	 * Get the amount of crimes in a zipcode for a given time period from your MySQL instance.
	 * This runs a SELECT statement and returns the name of the neighborhood and the number of crimes
	 * that occurred in a time range.
	 */
	@SuppressWarnings("deprecation")
	public List<String> getCrimeNumbersByZipCode(int ZipCode) throws SQLException {
		List<String> crimeStats = new ArrayList<String>();
		String selectCrimeStats =
			"SELECT CrimeSubCat,COUNT(CrimeSubCat) AS CNT " +
			"FROM " +
				"(SELECT BeatCrimes.Neighborhood AS Neighborhood,CrimeSubCat, OccurDate, Beat, BeatCrimes.ZipCode AS ZipCode " +
				"FROM " +
					"(SELECT Neighborhood, CrimeSubCat, OccurDate, Crimes.Beat AS Beat, Beat.ZipCode AS ZipCode " +
					 "FROM Crimes INNER JOIN Beat  " +
						"ON Crimes.Beat = Beat.Beat) " +
					 "AS BeatCrimes INNER JOIN ZipCodes " +
						"ON BeatCrimes.ZipCode = ZipCodes.ZipCode " +
				"WHERE BeatCrimes.ZipCode=? AND OccurDate >= '2017-01-01') AS CurrentTable " +
			"GROUP BY CrimeSubCat;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrimeStats);
			selectStmt.setInt(1, ZipCode);
//			Date beginning = new Date(2017, 1, 1);
//			Date end = new Date(2017, 12, 31);
//			java.sql.Date beginning2 = new java.sql.Date(beginning.getTime());
//			java.sql.Date end2 = new java.sql.Date(end.getTime());
//			selectStmt.setDate(2, '2008-01-01');
//			selectStmt.setString(3, '2018-12-31');
			results = selectStmt.executeQuery();
			
			while(results.next()) {
				String crimeSubCat = results.getString("CrimeSubCat");
				int cnt = results.getInt("CNT");
				
				String returnResult = crimeSubCat + ": " + cnt;
				crimeStats.add(returnResult);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimeStats;
	}
	
	/**
	 * Get the amount of times a crime occurred in a zipcode in a year it from your MySQL instance.
	 * This runs a SELECT statement and returns the name of the neighborhoods where the crime occurred and 
	 * the amount of times that crime occurred in a year.
	 */
	@SuppressWarnings("deprecation")
	public List<String> getCrimeNumbersByCrimeSubCat(int zipCode, String crimeSubCat, int year) throws SQLException {
		List<String> crimeStats = new ArrayList<String>();
		String selectCrimeStats =
			"SELECT CrimeSubCat,COUNT(CrimeSubCat) AS CNT " +
			"FROM " +
				"(SELECT BeatCrimes.Neighborhood AS Neighborhood,CrimeSubCat, OccurDate, Beat, BeatCrimes.ZipCode AS ZipCode " +
				"FROM " +
					"(SELECT Neighborhood, CrimeSubCat, OccurDate, Crimes.Beat AS Beat, Beat.ZipCode AS ZipCode " +
					 "FROM Crimes INNER JOIN Beat  " +
						"ON Crimes.Beat = Beat.Beat) " +
					 "AS BeatCrimes INNER JOIN ZipCodes " +
						"ON BeatCrimes.ZipCode = ZipCodes.ZipCode " +
				"WHERE BeatCrimes.ZipCode=? AND OccurDate BETWEEN ? AND ?) AS CurrentTable " +
			"WHERE CrimeSubCat=? " +
			"GROUP BY CrimeSubCat;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCrimeStats);
			selectStmt.setInt(1, zipCode);
			selectStmt.setString(2,	crimeSubCat);
			Date beginning = new Date(year, 1, 1);
			Date end = new Date(year, 12, 31);
			java.sql.Date beginning2 = new java.sql.Date(beginning.getTime());
			java.sql.Date end2 = new java.sql.Date(end.getTime());
			selectStmt.setDate(2, beginning2);
			selectStmt.setDate(3, end2);
			results = selectStmt.executeQuery();
			
			while(results.next()) {
				String neighborhood = results.getString("Neighborhood");
				int cnt = results.getInt("CNT");
				
				String returnResult = neighborhood + ": " + cnt;
				crimeStats.add(returnResult);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return crimeStats;
	}

	/**
	 * Delete the Crimes instance.
	 * This runs a DELETE statement.
	 */
	public Crimes delete(Crimes crime) throws SQLException {
		String deleteCrime = "DELETE FROM Crimes WHERE ReportId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteCrime);
			deleteStmt.setLong(1, crime.getReportId());
			deleteStmt.executeUpdate();

			// Return null so the caller can no longer operate on the Crimes instance.
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
}
