//Zhihua Wu

package aboutSeattle.dal;

import aboutSeattle.model.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/**
 * Data access object (DAO) class to interact with the underlying Users table in your MySQL
 * instance. This is used to store {@link RentalForecast} into your MySQL instance and retrieve 
 * {@link RentalForecast} from MySQL instance.
 */
public class RentalForecastDao {
	protected ConnectionManager connectionManager;
	
	// Single pattern: instantiation is limited to one object.
	private static RentalForecastDao instance = null;
	protected RentalForecastDao() {
		connectionManager = new ConnectionManager();
	}
	public static RentalForecastDao getInstance() {
		if(instance == null) {
			instance = new RentalForecastDao();
		}
		return instance;
	}

	/**
	 * Save the User instance by storing it in your MySQL instance.
	 * This runs a INSERT statement.
	 */
	
	public RentalForecast create(RentalForecast rentalForecast) throws SQLException {
		String insertRentalForecast = "INSERT INTO RentalForecast(ZipCode,RunDate,State,Metro,County,City,SizeRank,Zri,YoY,ZriRecordCnt)"
				+ " VALUES(?,?,?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertRentalForecast,Statement.RETURN_GENERATED_KEYS);
			// PreparedStatement allows us to substitute specific types into the query template.
			// For an overview, see:
			// http://docs.oracle.com/javase/tutorial/jdbc/basics/prepared.html.
			// http://docs.oracle.com/javase/7/docs/api/java/sql/PreparedStatement.html
			// For nullable fields, you can check the property first and then call setNull()
			// as applicable.
			insertStmt.setInt(1, rentalForecast.getZip().getZip());
			insertStmt.setDate(2, rentalForecast.getDate());
			insertStmt.setString(3, rentalForecast.getState());
			insertStmt.setString(4, rentalForecast.getMetro());
			insertStmt.setString(5, rentalForecast.getCounty());
			insertStmt.setString(6, rentalForecast.getCity());
			insertStmt.setInt(7, rentalForecast.getSizeRank());
			insertStmt.setInt(8, rentalForecast.getZri());
			insertStmt.setDouble(9, rentalForecast.getYoy());
			insertStmt.setInt(10, rentalForecast.getZriRecordCnt());
			// Note that we call executeUpdate(). This is used for a INSERT/UPDATE/DELETE
			// statements, and it returns an int for the row counts affected (or 0 if the
			// statement returns nothing). 
			insertStmt.executeUpdate();
			resultKey = insertStmt.getGeneratedKeys();
			int forecastId = -1;
			if(resultKey.next()) {
				forecastId = resultKey.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			rentalForecast.setForecastId(forecastId);
			return rentalForecast;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}// end of insert
	

	/**
	 * Update the LastName of the User instance.
	 * This runs a UPDATE statement.
	 */
	public RentalForecast updateCity(RentalForecast rentalForecast, String newCity) throws SQLException {
		String updateRentalForecast = "UPDATE RentalForecast SET City=? WHERE ForecastId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateRentalForecast);
			updateStmt.setString(1, newCity);
			updateStmt.setInt(2, rentalForecast.getForecastId());
			updateStmt.executeUpdate();
			
			// Update the person param before returning to the caller.
			rentalForecast.setCity(newCity);
			return rentalForecast;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}

	/**
	 * Delete the RentalForecast instance.
	 * This runs a DELETE statement.
	 */
	public RentalForecast delete(RentalForecast rentalForecast) throws SQLException {
		String deleteRentalForecast = "DELETE FROM RentalForecast WHERE ForecastId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteRentalForecast);
			deleteStmt.setInt(1, rentalForecast.getForecastId());
			deleteStmt.executeUpdate();

			// Return null so the caller can no longer operate on the User instance.
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}

	public RentalForecast getRentalForecastById(int forecastId) throws SQLException {
		String selectRentalForecast = "SELECT * FROM RentalForecast WHERE ForecastId=?;";
			Connection connection = null;
			PreparedStatement selectStmt = null;
			ResultSet results = null;
			try {
				connection = connectionManager.getConnection();
				selectStmt = connection.prepareStatement(selectRentalForecast);
				selectStmt.setInt(1, forecastId);
				results = selectStmt.executeQuery();
				ZipCodeDao zipDao = ZipCodeDao.getInstance();
				if(results.next()) {
					int resultForecastId = results.getInt("ForecastId");
					int zip = results.getInt("ZipCode");
					ZipCodes zipcode = zipDao.getZipByZipCode(zip);
					Date date = results.getDate("RunDate");
					String state = results.getString("State");
					String metro = results.getString("Metro");
					String county = results.getString("County");
					String city = results.getString("City");
					int sizeRank = results.getInt("SizeRank");
					int zri = results.getInt("Zri");
					double yoy = results.getDouble("YoY");
					int cnt = results.getInt("ZriRecordCnt");
					RentalForecast rentalForecast = new RentalForecast(resultForecastId,zipcode, date, state, metro,county,city,sizeRank,zri,yoy,cnt);
					return rentalForecast;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			} finally {
				if(connection != null) {
					connection.close();
				}
				if(selectStmt != null) {
					selectStmt.close();
				}
				if(results != null) {
					results.close();
				}
			}
			return null;
		} // end of insert 
	
	/**
	 * Get the RentalForecast record by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns a single RentalForecast instance.
	 */
	public List<RentalForecast> getRentalForecastByZip(int zip) throws SQLException {
		List<RentalForecast> rentalForecasts = new ArrayList<>();
		String selectRentalForecast = "SELECT * FROM RentalForecast WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRentalForecast);
			selectStmt.setInt(1, zip);
			results = selectStmt.executeQuery();
			ZipCodeDao zipDao = ZipCodeDao.getInstance();
			
			while(results.next()) {
				int fId = results.getInt("ForecastId");
				int resultZip = results.getInt("ZipCode");
				ZipCodes zipcode = zipDao.getZipByZipCode(resultZip);
				Date date = results.getDate("RunDate");
				String state = results.getString("State");
				String metro = results.getString("Metro");
				String county = results.getString("County");
				String city = results.getString("City");
				int sizeRank = results.getInt("SizeRank");
				int zri = results.getInt("Zri");
				double yoy = results.getDouble("YoY");
				int cnt = results.getInt("ZriRecordCnt");
				RentalForecast rentalForecast = new RentalForecast(fId, zipcode, date, state, metro,county,city,sizeRank,zri,yoy,cnt);
				rentalForecasts.add(rentalForecast);;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return rentalForecasts;
	}
	
	/**
	 * Get the matching Persons records by fetching from your MySQL instance.
	 * This runs a SELECT statement and returns a list of matching Persons.
	 */
	public List<RentalForecast> getRentalForecastByCity(String city) throws SQLException {
		List<RentalForecast> rentalForecasts = new ArrayList<>();
		String selectRentalForecasts =
			"SELECT * FROM RentalForecast WHERE City=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRentalForecasts);
			selectStmt.setString(1, city);
			results = selectStmt.executeQuery();
			ZipCodeDao zipDao = ZipCodeDao.getInstance();
			while(results.next()) {
				int zip = results.getInt("ZipCode");
				ZipCodes zipcode = zipDao.getZipByZipCode(zip);
				Date date = results.getDate("RunDate");
				String state = results.getString("State");
				String metro = results.getString("Metro");
				String county = results.getString("County");
				String resultCity = results.getString("City");
				int sizeRank = results.getInt("SizeRank");
				int zri = results.getInt("Zri");
				double yoy = results.getDouble("YoY");
				int cnt = results.getInt("ZriRecordCnt");
				RentalForecast rentalForecast = new RentalForecast(zipcode, date, state, metro,county,resultCity,sizeRank,zri,yoy,cnt);
				rentalForecasts.add(rentalForecast);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return rentalForecasts;
	}
}
