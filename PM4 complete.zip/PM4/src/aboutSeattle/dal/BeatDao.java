// Ugochi Madubata

package aboutSeattle.dal;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import aboutSeattle.model.*;
import aboutSeattle.model.ZipCodes;


/**
 * Data access object (DAO) class to interact with the underlying Beat table in your MySQL
 * instance. This is used to store {@link Beat} into your MySQL instance and retrieve 
 * {@link Beat} from MySQL instance.
 */
public class BeatDao {
	protected ConnectionManager connectionManager;
	
	// Single pattern: instantiation is limited to one object.
	private static BeatDao instance = null;
	protected BeatDao() {
		connectionManager = new ConnectionManager();
	}
	public static BeatDao getInstance() {
		if(instance == null) {
			instance = new BeatDao();
		}
		return instance;
	}

	/**
	 * Save the Beat instance by storing it in your MySQL instance.
	 * This runs a INSERT statement.
	 */
	public Beat create(Beat beat) throws SQLException {
		String insertBeat = "INSERT INTO Beat(Beat,Latitude,Longitude,ZipCode) VALUES(?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertBeat);
			
			insertStmt.setString(1, beat.getBeat());
			insertStmt.setDouble(2, beat.getLatitude());
			insertStmt.setDouble(3, beat.getLongitude());
			insertStmt.setInt(4, beat.getZipCode().getZip());
			
			insertStmt.executeUpdate();
			
			return beat;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
		}
	}
	
	/**
	 * Get the Beat record by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns a single Beat instance.
	 */
	public Beat getBeatFromBeat(String beat) throws SQLException {
		String selectBeat = "SELECT Beat,Latitude,Longitude,ZipCode FROM Beat WHERE Beat=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectBeat);
			selectStmt.setString(1, beat);
			
			results = selectStmt.executeQuery();
			ZipCodeDao zipCodeDao = ZipCodeDao.getInstance();
			
			if(results.next()) {
				String resultsBeat = results.getString("Beat");
				Double latitude = results.getDouble("Latitude");
				Double longitude = results.getDouble("Longitude");
				int zipCodeNumber = results.getInt("ZipCode");
				
				ZipCodes zipCode = zipCodeDao.getZipByZipCode(zipCodeNumber);
				
				Beat beats = new Beat(resultsBeat, latitude, longitude, zipCode);
				return beats;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}

	/**
	 * Get the Beat record by fetching it from your MySQL instance.
	 * This runs a SELECT statement and returns a single Beat instance.
	 */
	public List<Beat> getBeatFromZipCode(int zipCode) throws SQLException {
		List<Beat> beats = new ArrayList<Beat>();
		String selectBeat = "SELECT Beat,Latitude,Longitude,ZipCode FROM Beat WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectBeat);
			selectStmt.setInt(1, zipCode);
			
			results = selectStmt.executeQuery();
			ZipCodeDao zipCodeDao = ZipCodeDao.getInstance();
			
			while(results.next()) {
				String beat = results.getString("Beat");
				Double latitude = results.getDouble("Latitude");
				Double longitude = results.getDouble("Longitude");
				int resultZipCode = results.getInt("ZipCode");
				
				ZipCodes newZipCode = zipCodeDao.getZipByZipCode(resultZipCode);
				
				Beat newBeat = new Beat(beat, latitude, longitude, newZipCode);
				beats.add(newBeat);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return beats;
	}
	
	/**
	 * Update the Latitude of the Beat instance.
	 * This runs a UPDATE statement.
	 */
	public Beat updateLatitude(Beat beat, Double newLatitude) throws SQLException {
		String updateBeat = "UPDATE Beat SET Latitude=? WHERE Beat=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateBeat);
			updateStmt.setDouble(1, newLatitude);
			updateStmt.setString(2, beat.getBeat());
			updateStmt.executeUpdate();
			
			beat.setLatitude(newLatitude);
			return beat;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	/**
	 * Update the Longitude of the Beat instance.
	 * This runs a UPDATE statement.
	 */
	public Beat updateLongitude(Beat beat, Double newLongitude) throws SQLException {
		String updateBeat = "UPDATE Beat SET Longitude=? WHERE Beat=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateBeat);
			updateStmt.setDouble(1, newLongitude);
			updateStmt.setString(2, beat.getBeat());
			updateStmt.executeUpdate();
			
			beat.setLatitude(newLongitude);
			return beat;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}

	/**
	 * Delete the Beat instance.
	 * This runs a DELETE statement.
	 */
	public Beat delete(Beat beat) throws SQLException {
		String deleteBeat = "DELETE FROM Beat WHERE Beat=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteBeat);
			deleteStmt.setString(1, beat.getBeat());
			deleteStmt.executeUpdate();

			// Return null so the caller can no longer operate on the Beat instance.
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
}
