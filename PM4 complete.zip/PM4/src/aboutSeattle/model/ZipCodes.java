//Zhihua Wu

/*
CREATE TABLE ZipCodes (
ZipCode INT,
City VARCHAR(100),
County VARCHAR(100),
State VARCHAR(100),
CONSTRAINT pk_ZipCodes_ZipCode
	PRIMARY KEY (ZipCode)
);
*/
package aboutSeattle.model;

public class ZipCodes {

	private int zipcode;
	private String city;
	private String county;
	private String state;
	
	public ZipCodes(int zipcode, String city, String county, String state) {
		this.zipcode = zipcode;
		this.city = city;
		this.state = state;
		this.county = county;
	}
	
	
	// This constructor can be used for reading records from MySQL, where we only have the zip,
	// such as a foreign key reference to zip.
	// Given zip, we can fetch the full Historical Mediem Rental price per square foot record.
	public ZipCodes(int zipcode) {
		this.zipcode = zipcode;
	}

	/** Getters and setters. */
	
	public int getZip() {
		return zipcode;
	}


	public void setZip(int zipcode) {
		this.zipcode = zipcode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCounty() {
		return county;
	}


	public void setCounty(String county) {
		this.county = county;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}
	
	}
