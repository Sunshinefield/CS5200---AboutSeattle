package aboutSeattle.model;

/**
 * Beat is a simple, plain old java objects (POJO).
 */
public class Beat {
	protected String beat;
	protected Double latitude;
	protected Double longitude;
	protected ZipCodes zipCode;
	
	
	/**
	 * @param beat the police beat.
	 * @param latitude the latitude of the center of the police beat.
	 * @param longitude the longitude of the center of the police beat.
	 * @param zipCode the zipcode the center of the beat resides in.
	 */
	public Beat(String beat, Double latitude, Double longitude, ZipCodes zipCode) {
		this.beat = beat;
		this.latitude = latitude;
		this.longitude = longitude;
		this.zipCode = zipCode;
	}
	
	public Beat(Double latitude, Double longitude, ZipCodes zipCode) {
		this.latitude = latitude;
		this.longitude = longitude;
		this.zipCode = zipCode;
	}
	
	public Beat(String beat) {
		this.beat = beat;
	}
	
	/** Getters and setters. */

	/**
	 * @return the beat
	 */
	public String getBeat() {
		return beat;
	}

	/**
	 * @param beat the beat to set
	 */
	public void setBeat(String beat) {
		this.beat = beat;
	}

	/**
	 * @return the latitude
	 */
	public Double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public Double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the zipCode
	 */
	public ZipCodes getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(ZipCodes zipCode) {
		this.zipCode = zipCode;
	}	
}
