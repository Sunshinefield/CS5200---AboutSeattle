package aboutSeattle.model;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class Crimes {
	/**
	 * The enumeration for the different crime subcategories in the crimes dataset.
	 * 
	 * @author Goch
	 *
	 */
	public enum CrimeSubCat {
		AGGRAVATED_ASSAULT("AGGRAVATED ASSAULT"), AGGRAVATED_ASSAULT_DV("AGGRAVATED ASSAULT-DV"), ARSON("ARSON"), BURGLARY_COMMERCIAL("BURGLARY-COMMERCIAL"), BURGLARY_COMMERCIAL_SECURE_PARKING("BURGLARY-COMMERCIAL-SECURE-PARKING"), BURGLARY_RESIDENTIAL("BURGLARY-RESIDENTIAL"), 
		BURGLARY_RESIDENTIAL_SECURE_PARKING("BURGLARY-RESIDENTIAL-SECURE-PARKING"), CAR_PROWL("CAR PROWL"), DISORDERLY_CONDUCT("DISORDERLY CONDUCT"), DUI("DUI"), FAMILY_OFFENSE_NONVIOLENT("FAMILY OFFENSE-NONVIOLENT"), GAMBLE("GAMBLE"), HOMICIDE("HOMICIDE"), 
		LIQUOR_LAW_VIOLATION("LIQUOR LAW VIOLATION"), LOITERING("LOITERING"), MOTOR_VEHICLE_THEFT("MOTOR VEHICLE THEFT"), NARCOTIC("NARCOTIC"), PORNOGRAPHY("PORNOGRAPHY"), PROSTITUTION("PROSTITUTION"), RAPE("RAPE"), ROBBERY_COMMERCIAL("ROBBERY-COMMERCIAL"), 
		ROBBERY_RESIDENTIAL("ROBBERY-RESIDENTIAL"), ROBBERY_STREET("ROBBERY-STREET"), SEX_OFFENSE_OTHER("SEX OFFENSE-OTHER"), THEFT_ALL_OTHER("THEFT-ALL OTHER"), THEFT_BICYCLE("THEFT-BICYCLE"), THEFT_BUILDING("THEFT-BUILDING"), THEFT_SHOPLIFT("THEFT-SHOPLIFT"), 
		TRESPASS("TRESPASS"), WEAPON("WEAPON"), BLANK("");
		
		private CrimeSubCat(String crime) {
			this.crime = crime;
		}
		
		private static final Map<String, CrimeSubCat> crimeSubCatMap = new HashMap<String,CrimeSubCat>();
		static {
			for (CrimeSubCat cat : CrimeSubCat.values()) {
				crimeSubCatMap.put(cat.crime, cat);
			}
		}
		
		public static CrimeSubCat fromString(String crime) {
			CrimeSubCat cat = crimeSubCatMap.get(crime);
			if (cat == null) {
				return null;
			}
			
			return cat;
		}
		
		
		/**
		 * Creating a variable so we can translate the crime subcategories as they are written in the spreadsheet to the java enums.
		 */
		private String crime;
		
		/**
		 * @return the text version of the crime subcategory.
		 */
		public String getCrime() {
			return crime;
		}
		
	}
	
	protected long reportId;
	protected Date reportedDate;
	protected Date occuredDate;
	protected CrimeSubCat crimeSubCat;
	protected String description;
	protected String precinct;
	protected String sector;
	protected Beat beat;
	protected String neighborhood;
	
	/**
	 * Creates a crime from a report id, the reported date, the reported time, the date the crime occurred, the crime's 
	 * subcategory, a description of the crime, and the precinct, sector, beat, and neighborhood the crime occured in.
	 * @param reportId
	 * @param reportedDate
	 * @param occuredDate
	 * @param crimeSubCat
	 * @param description
	 * @param precinct
	 * @param sector
	 * @param beat
	 * @param neighborhood
	 */
	public Crimes(long reportId, Date reportedDate, Date occuredDate, CrimeSubCat crimeSubCat,
			String description, String precinct, String sector, Beat beat, String neighborhood) {
		this.reportId = reportId;
		this.reportedDate = reportedDate;
		this.occuredDate = occuredDate;
		this.crimeSubCat = crimeSubCat;
		this.description = description;
		this.precinct = precinct;
		this.sector = sector;
		this.beat = beat;
		this.neighborhood = neighborhood;
	}
	
	/**
	 * Creates a crime from all elements of a crime except the report id. Necessary to deal with the auto-incrementing nature 
	 * of report id.
	 * @param reportedDate
	 * @param occuredDate
	 * @param crimeSubCat
	 * @param description
	 * @param precinct
	 * @param sector
	 * @param beat
	 * @param neighborhood
	 */
	public Crimes(Date reportedDate, Date occuredDate, CrimeSubCat crimeSubCat,
			String description, String precinct, String sector, Beat beat, String neighborhood) {
		this.reportedDate = reportedDate;
		this.occuredDate = occuredDate;
		this.crimeSubCat = crimeSubCat;
		this.description = description;
		this.precinct = precinct;
		this.sector = sector;
		this.beat = beat;
		this.neighborhood = neighborhood;
	}

	/**
	 * Creates a crime from the report id. Necessary to deal with report id as a primary key and the auto incrementing 
	 * nature of report id.
	 * @param reportId
	 */
	public Crimes(long reportId) {
		this.reportId = reportId;
	}
	
	/**
	 * @return the reportId
	 */
	public long getReportId() {
		return reportId;
	}

	/**
	 * @param reportId the reportId to set
	 */
	public void setReportId(long reportId) {
		this.reportId = reportId;
	}

	/**
	 * @return the reportedDate
	 */
	public Date getReportedDate() {
		return reportedDate;
	}

	/**
	 * @param reportedDate the reportedDate to set
	 */
	public void setReportedDate(Date reportedDate) {
		this.reportedDate = reportedDate;
	}

	/**
	 * @return the occuredDate
	 */
	public Date getOccuredDate() {
		return occuredDate;
	}

	/**
	 * @param occuredDate the occuredDate to set
	 */
	public void setOccuredDate(Date occuredDate) {
		this.occuredDate = occuredDate;
	}

	/**
	 * @return the crimeSubCat
	 */
	public CrimeSubCat getCrimeSubCat() {
		return crimeSubCat;
	}

	/**
	 * @param crimeSubCat the crimeSubCat to set
	 */
	public void setCrimeSubCat(CrimeSubCat crimeSubCat) {
		this.crimeSubCat = crimeSubCat;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the precinct
	 */
	public String getPrecinct() {
		return precinct;
	}

	/**
	 * @param precinct the precinct to set
	 */
	public void setPrecinct(String precinct) {
		this.precinct = precinct;
	}

	/**
	 * @return the sector
	 */
	public String getSector() {
		return sector;
	}

	/**
	 * @param sector the sector to set
	 */
	public void setSector(String sector) {
		this.sector = sector;
	}

	/**
	 * @return the beat
	 */
	public Beat getBeat() {
		return beat;
	}

	/**
	 * @param beat the beat to set
	 */
	public void setBeat(Beat beat) {
		this.beat = beat;
	}

	/**
	 * @return the neighborhood
	 */
	public String getNeighborhood() {
		return neighborhood;
	}

	/**
	 * @param neighborhood the neighborhood to set
	 */
	public void setNeighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}	
}
