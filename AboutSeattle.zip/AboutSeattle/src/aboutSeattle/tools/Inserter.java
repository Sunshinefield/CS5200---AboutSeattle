//Zhihua Wu

package aboutSeattle.tools;

import aboutSeattle.dal.*;
import aboutSeattle.model.*;

import java.sql.SQLException;
import java.sql.Date;
import java.util.List;


/**
 * main() runner, used for the app demo.
 * 
 * Instructions:
 * 1. Create a new MySQL schema and then run the CREATE TABLE statements from lecture:
 * http://goo.gl/86a11H.
 * 2. Update ConnectionManager with the correct user, password, and schema.
 */
public class Inserter {

	public static void main(String[] args) throws SQLException {
		// DAO instances.
		HistoricalRentalDao historicalRentalDao = HistoricalRentalDao.getInstance();
		RentalForecastDao rentalForecastDao = RentalForecastDao.getInstance();
		ZipCodeDao zipCodeDao = ZipCodeDao.getInstance();
		
		// INSERT objects from our model.
		ZipCodes zip1 = new ZipCodes(98052, "Remond", "King", "WA");
		zip1 = zipCodeDao.create(zip1);
		ZipCodes zip2 = new ZipCodes(98012, "Bothell", "Snohomish", "WA");
		zip2 = zipCodeDao.create(zip2);
		ZipCodes zip3 = new ZipCodes(98103, "Seattle", "King", "WA");
		zip3 = zipCodeDao.create(zip3);
		
		
		HistoricalRental historicalRental1 = new HistoricalRental(zip1, "Redmond", "WA", "Seattle-Tacoma-Bellevue", "King", 
				1.4180000000, 1.4180000000, 1.4010000000, 1.4010000000, 1.6290000000, 1.6290000000);
		historicalRental1 = historicalRentalDao.create(historicalRental1);
		HistoricalRental historicalRental2 = new HistoricalRental(zip2, "Bothell", "WA", "Seattle-Tacoma-Bellevue", "Snohomish", 
				1.1340000000, 1.0980000000, 1.1430000000, 1.2050000000, 1.2480000000, 1.2680000000);
		historicalRental2 = historicalRentalDao.create(historicalRental2);
		HistoricalRental historicalRental3 = new HistoricalRental(zip3, "Seattle", "WA", "Seattle-Tacoma-Bellevue", "King", 
				1.7760000000, 1.8420000000, 1.9010000000, 2.0860000000, 2.1400000000, 2.2400000000);
		historicalRental3 = historicalRentalDao.create(historicalRental3);

		//Create a Date value
		Date date = Date.valueOf("2018-9-30");
		
		RentalForecast rentalForecast1 = new RentalForecast(zip1,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Redmond",75,2586,-0.052400147000,19679);
		rentalForecast1 = rentalForecastDao.create(rentalForecast1);

		RentalForecast rentalForecast2 = new RentalForecast(zip2,date,"WA","Seattle-Tacoma-Bellevue",
				"Snohomish","Bothell",152,2294,-0.041771094000,20473);
		rentalForecast2 = rentalForecastDao.create(rentalForecast2);

		RentalForecast rentalForecast3 = new RentalForecast(zip3,date,"WA","Seattle-Tacoma-Bellevue",
				"King","Seattle",189,2569,-0.074234234000,17641);
		rentalForecast3 = rentalForecastDao.create(rentalForecast3);

		
		// READ.
		
		ZipCodes z1 = zipCodeDao.getZipByZipCode(98103);
		System.out.format("Reading ZipCodes:%n z:%d%n c:%s%n ct:%s%n s:%s%n\n",
				z1.getZip(),
				z1.getCity(),
				z1.getCounty(),
				z1.getState());
		
		List<ZipCodes> zList1 = zipCodeDao.getZipByCity("Seattle");
		for(ZipCodes z : zList1) {
			System.out.format("Looping ZipCodes:%n z:%d%n c:%s%n ct:%s%n s:%s%n\n",
					z.getZip(),
					z.getCity(),
					z.getCounty(),
					z.getState());
		}
		
		HistoricalRental h1 = historicalRentalDao.getHistoricalRentalById(1);
		System.out.format("Reading HistoricalRental:%n z:%d%n c:%s%n s:%s%n m:%s%n ct:%s%n p13:%.4f%n p14:%.4f%n p15:%.4f%n p16:%.4f%n p17:%.4f%n p18:%.4f%n\n",
				h1.getZip().getZip(),
				h1.getCity(),
				h1.getState(),
				h1.getMetro(),
				h1.getCounty(),
				h1.getP2013(),
				h1.getP2014(),
				h1.getP2015(),
				h1.getP2016(),
				h1.getP2017(),
				h1.getP2018());
		

		List<HistoricalRental> hList1 = historicalRentalDao.getHistoricalRenatlByZip(98004);
		for(HistoricalRental h : hList1 ) {
			System.out.format("Looping historicalRental:%n z:%d%n c:%s%n s:%s%n m:%s%n ct:%s%n p13:%.4f%n p14:%.4f%n p15:%.4f%n p16:%.4f%n p17:%.4f%n p18:%.4f%n\n",
					h.getZip().getZip(),
					h.getCity(),
					h.getState(),
					h.getMetro(),
					h.getCounty(),
					h.getP2013(),
					h.getP2014(),
					h.getP2015(),
					h.getP2016(),
					h.getP2017(),
					h.getP2018());
		}

		
		List<RentalForecast> rList = rentalForecastDao.getRentalForecastByZip(98103);
		for(RentalForecast r : rList) {
			System.out.format("Reading RentalForecast:%n z:%d%n d:%s%n s:%s%n m:%s%n ct:%s%n c:%s%n sr:%d%n zrt:%d%n yoy:%.4f%n zricnt:%d%n\n",
					r.getZip().getZip(),
					r.getDate(),
					r.getState(),
					r.getMetro(),
					r.getCounty(),
					r.getCity(),
					r.getSizeRank(),
					r.getZri(),
					r.getYoy(),
					r.getZriRecordCnt());
		}
		
		
		List<RentalForecast> rList1 = rentalForecastDao.getRentalForecastByCity("Seattle");
		for(RentalForecast r : rList1) {
			System.out.format("Looping RentalForecast:%n z:%d%n d:%s%n s:%s%n m:%s%n ct:%s%n c:%s%n sr:%d%n zrt:%d%n yoy:%.4f%n zricnt:%d%n\n",
					r.getZip().getZip(),
					r.getDate(),
					r.getState(),
					r.getMetro(),
					r.getCounty(),
					r.getCity(),
					r.getSizeRank(),
					r.getZri(),
					r.getYoy(),
					r.getZriRecordCnt());
		}

		//Update
		HistoricalRental historicalRentalUpdate = historicalRentalDao.updateCity(historicalRental1, "NewCity");
		System.out.format("Updating historicalRental: li:%d c:%s z:%s \n",
				historicalRentalUpdate.getListingId(), historicalRentalUpdate.getCity() ,historicalRentalUpdate.getZip().getZip());
		
		RentalForecast rentalForecastUpdate =  rentalForecastDao.updateCity(rentalForecast1, "NewCity");
		System.out.format("Updating rentalForecast: fi:%d c:%s z:%s  \n",
				rentalForecastUpdate.getForecastId(), rentalForecastUpdate.getCity(), rentalForecastUpdate.getZip().getZip());

		ZipCodes zipCodeUpdate =  zipCodeDao.updateCity(zip1, "NewCity");
		System.out.format("Updating zipcode: fi:%d c:%s z:%s  \n",
				zipCodeUpdate.getZip(), zipCodeUpdate.getCity(), zipCodeUpdate.getState());

		
		//Delete
		HistoricalRental deleteHistoricalRental = historicalRentalDao.delete(historicalRental1);
		System.out.println("Deleted 1st historicalRental:"+ deleteHistoricalRental);
		
		RentalForecast deleteRentalForecast = rentalForecastDao.delete(rentalForecast1);
		System.out.println("Deleted 1st rentalForecast:"+ deleteRentalForecast);
		
		ZipCodes deleteZipCode = zipCodeDao.delete(zip1);
		System.out.println("Deleted 1st zipcode:"+ deleteZipCode);
		
	}
}
