//Zhihua Wu

package aboutSeattle.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import aboutSeattle.model.*;

public class HistoricalRentalDao {

	protected ConnectionManager connectionManager;

	private static HistoricalRentalDao instance = null;
	protected HistoricalRentalDao() {
		connectionManager = new ConnectionManager();
	}
	public static HistoricalRentalDao getInstance() {
		if(instance == null) {
			instance = new HistoricalRentalDao();
		}
		return instance;
	}

	public HistoricalRental create(HistoricalRental historicalRental) throws SQLException {
		String insertHistoricalRental = "INSERT INTO HistoricalRental(ZipCode,City,State,Metro,County,Price_2013,Price_2014,Price_2015,Price_2016,Price_2017,Price_2018)"
				+ " VALUES(?,?,?,?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertHistoricalRental,Statement.RETURN_GENERATED_KEYS);
			
			insertStmt.setInt(1, historicalRental.getZip().getZip());
			insertStmt.setString(2, historicalRental.getCity());
			insertStmt.setString(3, historicalRental.getState());
			insertStmt.setString(4, historicalRental.getMetro());
			insertStmt.setString(5, historicalRental.getCounty());
			insertStmt.setDouble(6, historicalRental.getP2013());
			insertStmt.setDouble(7, historicalRental.getP2014());
			insertStmt.setDouble(8, historicalRental.getP2015());
			insertStmt.setDouble(9, historicalRental.getP2016());
			insertStmt.setDouble(10, historicalRental.getP2017());
			insertStmt.setDouble(11, historicalRental.getP2018());
			
			insertStmt.executeUpdate();
			
			resultKey = insertStmt.getGeneratedKeys();
			int listingId = -1;
			if(resultKey.next()) {
				listingId = resultKey.getInt(1);
			} else {
				throw new SQLException("Unable to retrieve auto-generated key.");
			}
			historicalRental.setListingId(listingId);;
			return historicalRental;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}// end of insert
	
	public HistoricalRental getHistoricalRentalById(int listingId) throws SQLException {
		String selectHistoricalRental = "SELECT * FROM HistoricalRental WHERE ListingId=?;";
			Connection connection = null;
			PreparedStatement selectStmt = null;
			ResultSet results = null;
			try {
				connection = connectionManager.getConnection();
				selectStmt = connection.prepareStatement(selectHistoricalRental);
				selectStmt.setInt(1, listingId);
				results = selectStmt.executeQuery();
				ZipCodeDao zipDao = ZipCodeDao.getInstance();
				if(results.next()) {
					int resultListingId = results.getInt("ListingId");
					int zipcode = results.getInt("ZipCode");
					ZipCodes zip = zipDao.getZipByZipCode(zipcode);
					String city = results.getString("City");
					String state = results.getString("State");
					String metro = results.getString("Metro");
					String county = results.getString("County");
					double p2013 = results.getDouble("Price_2013");
					double p2014 = results.getDouble("Price_2014");
					double p2015 = results.getDouble("Price_2015");
					double p2016 = results.getDouble("Price_2016");
					double p2017 = results.getDouble("Price_2017");
					double p2018 = results.getDouble("Price_2018");

					HistoricalRental historicalRental = new HistoricalRental(resultListingId, zip, city, state,
							metro, county, p2013, p2014, p2015, p2016, p2017, p2018);
					return historicalRental;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			} finally {
				if(connection != null) {
					connection.close();
				}
				if(selectStmt != null) {
					selectStmt.close();
				}
				if(results != null) {
					results.close();
				}
			}
			return null;
		} // end of insert 
	
	public List<HistoricalRental> getHistoricalRenatlByZip(int zip) throws SQLException{
		List<HistoricalRental> historicalRentals = new ArrayList<>();
		String selectHistoricalRentals =
			"SELECT * FROM HistoricalRental WHERE ZipCode=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectHistoricalRentals);
			selectStmt.setInt(1, zip);
			results = selectStmt.executeQuery();
			ZipCodeDao zipDao = ZipCodeDao.getInstance();
			while(results.next()) {
				int resultListingId = results.getInt("ListingId");
				int resultZip = results.getInt("ZipCode");
				ZipCodes zipcode = zipDao.getZipByZipCode(resultZip);
				String city = results.getString("City");
				String state = results.getString("State");
				String metro = results.getString("Metro");
				String county = results.getString("County");
				double p2013 = results.getDouble("Price_2013");
				double p2014 = results.getDouble("Price_2014");
				double p2015 = results.getDouble("Price_2015");
				double p2016 = results.getDouble("Price_2016");
				double p2017 = results.getDouble("Price_2017");
				double p2018 = results.getDouble("Price_2018");

				HistoricalRental historicalRental = new HistoricalRental(resultListingId, zipcode, city, state,
						metro, county, p2013, p2014, p2015, p2016, p2017, p2018);
				historicalRentals.add(historicalRental);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return historicalRentals;
	} // end of select 
	
	public List<HistoricalRental> getHistoricalRenatlByCity(String city) throws SQLException{
		List<HistoricalRental> historicalRentals = new ArrayList<>();
		String selectHistoricalRentals =
			"SELECT * FROM HistoricalRental WHERE City=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectHistoricalRentals);
			selectStmt.setString(1, city);
			results = selectStmt.executeQuery();
			ZipCodeDao zipDao = ZipCodeDao.getInstance();
			while(results.next()) {
				int zip = results.getInt("ZipCode");
				ZipCodes zipcode = zipDao.getZipByZipCode(zip);
				String resultCity = results.getString("City");
				String state = results.getString("State");
				String metro = results.getString("Metro");
				String county = results.getString("County");
				double p2013 = results.getDouble("Price_2013");
				double p2014 = results.getDouble("Price_2014");
				double p2015 = results.getDouble("Price_2015");
				double p2016 = results.getDouble("Price_2016");
				double p2017 = results.getDouble("Price_2017");
				double p2018 = results.getDouble("Price_2018");

				HistoricalRental historicalRental = new HistoricalRental(zipcode, resultCity, state,
						metro, county, p2013, p2014, p2015, p2016, p2017, p2018);
				historicalRentals.add(historicalRental);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return historicalRentals;
	} // end of select 
	
	/**
	 * Update the City of the HistoricalRental instance.
	 * This runs a UPDATE statement.
	 */
	public HistoricalRental updateCity(HistoricalRental historicalRental, String newCity) throws SQLException {
		String updateHistoricalRental = "UPDATE HistoricalRental SET City=? WHERE listingId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateHistoricalRental);
			updateStmt.setString(1, newCity);
			updateStmt.setInt(2, historicalRental.getListingId());
			updateStmt.executeUpdate();
			
			// Update the person param before returning to the caller.
			historicalRental.setCity(newCity);
			return historicalRental;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	 public HistoricalRental delete(HistoricalRental historicalRental) throws SQLException{
			String deleteHistoricalRental = "DELETE FROM HistoricalRental WHERE listingiD=?;";
			
			Connection connection = null;
			PreparedStatement deleteStmt = null;
			try {
				connection = connectionManager.getConnection();
				deleteStmt = connection.prepareStatement(deleteHistoricalRental);
				deleteStmt.setInt(1, historicalRental.getListingId());
				deleteStmt.executeUpdate();
				return null;
			} catch (SQLException e) {
				e.printStackTrace();
				throw e;
			} finally {
				if(connection != null) {
					connection.close();
				}
				if(deleteStmt != null) {
					deleteStmt.close();
				}
			}
	 }

}
